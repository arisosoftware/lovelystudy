# -*- coding: utf-8 -*-
# @File    : model.py
# @Author  : Ariso Software
# @Time    : 2020/07/01
# @Desc    :

from random import random
from numpy import array
from numpy import cumsum
from matplotlib import pyplot
from pandas import DataFrame
 
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.layers import Dense, Embedding, LSTM, SpatialDropout1D,TimeDistributed,Bidirectional
 




# 构建测试数据 
def get_sequence(n_timesteps):
	# 问题定义为介于0和1之间的随机值序列。该序列被用作问题的输入，每个时间步长提供一个数字。
	X = array([random() for _ in range(n_timesteps)])
	# 使用1/4序列长度的阈值
	limit = n_timesteps/4.0
	# 计算输出序列，以确定每个累积总和值是否超过阈值。
	y = array([0 if x < limit else 1 for x in cumsum(X)])
	# 将所有这些组合在一起，以序列的长度作为输入，并返回新问题案例的X和y分量。
	X = X.reshape(1, n_timesteps, 1)
	y = y.reshape(1, n_timesteps, 1)
	return X, y

# 构建lstm 模型
def get_lstm_model(n_timesteps, backwards):
	model = Sequential()
	model.add(LSTM(20, input_shape=(n_timesteps, 1), return_sequences=True, go_backwards=backwards))
	model.add(TimeDistributed(Dense(1, activation='sigmoid')))
	model.compile(loss='binary_crossentropy', optimizer='adam')
	return model

# 构建双向lstm 模型
def get_bi_lstm_model(n_timesteps, mode):
	model = Sequential()
	model.add(Bidirectional(LSTM(20, return_sequences=True), input_shape=(n_timesteps, 1), merge_mode=mode))
	model.add(TimeDistributed(Dense(1, activation='sigmoid')))
	model.compile(loss='binary_crossentropy', optimizer='adam')
	return model

#训练入口
def train_model(model, n_timesteps):
	loss = list()
	for _ in range(250):
		# generate new random sequence
		X,y = get_sequence(n_timesteps)
		# fit model for one epoch on this sequence
		hist = model.fit(X, y, epochs=1, batch_size=1, verbose=0)
		loss.append(hist.history['loss'][0])
	return loss

#主程序 使用新的10个时间步序列来测试此功能
 
n_timesteps = 10
results = DataFrame()
# lstm 顺序
model = get_lstm_model(n_timesteps, False)
# 查看模型结构
model.summary()

results['lstm_forw'] = train_model(model, n_timesteps)
# lstm 逆序
model = get_lstm_model(n_timesteps, True)
# 查看模型结构
model.summary()

results['lstm_back'] = train_model(model, n_timesteps)
# 链接双向
model = get_bi_lstm_model(n_timesteps, 'concat')

# 查看模型结构
model.summary()

results['bilstm_con'] = train_model(model, n_timesteps)
# 画结果图表示
results.plot()
pyplot.show()

